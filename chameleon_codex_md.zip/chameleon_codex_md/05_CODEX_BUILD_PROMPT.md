# Codex Build Prompt — Flutter + Flame Chameleon Mechanics Demo

You are building a playable Flutter + Flame mechanics demo for a chameleon puzzle game.

Use the uploaded assets exactly as described in `01_ASSET_MANIFEST.md`.

The goal is to validate gameplay mechanics, not to build the final game.

## Main Requirements

Build a portrait mobile Flutter + Flame demo with:

- 5 x 7 grid
- Chameleon below the board
- Gesture-first controls
- Swallow mechanic
- Spit mechanic
- Color mixing
- Cluster matching
- Cascades / chain reactions
- Simple HUD
- At least 3 handcrafted test levels

## Assets

Assets should live under:

```txt
assets/images/
```

Use these exact files:

```txt
backgrpund_jungle.png
board_5x7_empty.png
ladybug_red.png
ladybug_blue.png
ladybug_yellow.png
ladybug_green.png
ladybug_purple.png
ladybug_orange.png
fx_pop.png
fx_sparkle.png
fx_color_splash_red.png
fx_color_splash_blue.png
fx_color_splash_yellow.png
fx_combo_burst.png
ui_panel_small.png
ui_panel_wide.png
```

Chameleon assets:

```txt
chameleon/neutral/chameleon_idle01.png
chameleon/neutral/chameleon_idle02.png
chameleon/neutral/chameleon_walk01.png
chameleon/neutral/chameleon_walk02.png
chameleon/neutral/chameleon_walk03.png
chameleon/neutral/chameleon_swallow01.png
chameleon/neutral/chameleon_swallow02.png
chameleon/neutral/chameleon_swallow03.png
```

And the same filenames inside these color folders:

```txt
chameleon/red/
chameleon/blue/
chameleon/yellow/
chameleon/green/
chameleon/purple/
chameleon/orange/
```

Important:

- There are no dedicated spit frames in the ZIP.
- Use the swallow animation reversed as a temporary spit animation.

## Controls

Gesture-first controls:

| Gesture | Action |
|---|---|
| Swipe left | Move chameleon one column left |
| Swipe right | Move chameleon one column right |
| Tap | Swallow from current column |
| Swipe up | Spit held color into current column |

Add debug keyboard controls:

| Key | Action |
|---|---|
| Left / A | Move left |
| Right / D | Move right |
| Space / J | Swallow |
| Enter / K | Spit |
| R | Reset current level |
| 1 / 2 / 3 / 4 | Switch demo level |

## Board Rules

Use:

```txt
columns = 5
rows = 7
```

Represent columns bottom-to-top.

Example:

```dart
[BugColor.blue, BugColor.red, BugColor.yellow]
```

This means:

```txt
bottom: blue
middle: red
top: yellow
```

## Chameleon State

The chameleon has:

```dart
int columnIndex;
BugColor? heldColor;
MouthType mouthType; // empty, base, mixed
```

When empty:

- Use neutral chameleon animation.

When holding a color:

- Use that color’s chameleon animation folder.

## Color Mixing

Base colors:

```txt
red
blue
yellow
```

Mixed colors:

```txt
purple
green
orange
```

Implement:

```txt
red + blue = purple
blue + red = purple
blue + yellow = green
yellow + blue = green
red + yellow = orange
yellow + red = orange
red + red = red
blue + blue = blue
yellow + yellow = yellow
```

Rules:

- Only base colors can be used as ingredients.
- Mixed colors can be matched/cleared on the board.
- Mixed colors cannot be mixed again.
- If the chameleon already holds a mixed color, block swallow and show `Spit first!`.
- If a mix is invalid, do not remove the board piece.

## Swallow Mechanic

When swallow is triggered:

1. Check current column.
2. If empty, show `Nothing to swallow!`.
3. Look at the bottom-most ladybug only.
4. Validate whether it can be stored/mixed.
5. If valid, remove it from index 0.
6. Update held color / mouth type.
7. Play swallow animation.

Important:

- Swallow only removes the bottom-most ladybug.
- Ladybugs never skip positions.
- Column gravity is automatic because columns are bottom-to-top lists.

## Spit Mechanic

When spit is triggered:

1. If no held color, show `Nothing to spit!`.
2. If current column is full, show `Column full!`.
3. Otherwise insert held color at index 0 of the current column.
4. This pushes existing pieces upward.
5. Clear held color.
6. Increment move count.
7. Play spit animation using reversed swallow frames.
8. Resolve matches and cascades.

Example:

```txt
Before bottom-to-top:
blue, red, yellow

Spit purple.

After bottom-to-top:
purple, blue, red, yellow
```

## Match Rule

Use cluster matching.

A group clears when 3 or more same-color ladybugs are connected orthogonally:

```txt
up, down, left, right
```

Diagonal does not count.

Multiple groups can clear at the same time.

## Cascade Logic

After every successful spit:

```dart
cascadeCount = 0
while matches exist:
  cascadeCount += 1
  clear all matching groups
  spawn FX
  apply gravity to all columns
  delay briefly so player sees the reaction
```

Update:

```txt
status text
ladybugs removed
highest cascade
objective progress
```

If no match happens:

```txt
No match
```

## FX

On clear:

- Spawn `fx_pop.png` at each cleared cell.

On red/blue/yellow clear:

- Optionally use the color-specific splash.

On cascade x2 or higher:

- Spawn `fx_combo_burst.png` near the center of the board.

## HUD

Show:

```txt
moves
held color
objective
ladybugs removed
highest cascade
status text
current level name
```

Use Flutter overlay text or Flame TextComponents. The uploaded UI panel PNGs may be used as background decorations for HUD labels, but they are optional for the mechanics demo.

## Level Definitions

Implement at least these demo levels from `04_LEVELS_AND_TESTING.md`:

1. Basic Clear
2. Color Mixing
3. Cross-Column Cascade
4. Push Setup

Allow level switching using keyboard keys for debug.

## Acceptance Criteria

The demo is successful when:

- The background renders.
- The empty board renders.
- Ladybugs render in a 5 x 7 grid.
- Chameleon renders below the board.
- Swipe left/right moves the chameleon.
- Tap swallows the bottom-most ladybug from the current column.
- Swipe up spits the held color into the current column.
- Chameleon changes color based on held color.
- Chameleon can mix red + blue into purple.
- Chameleon can mix blue + yellow into green.
- Chameleon can mix red + yellow into orange.
- Mixed colors cannot be mixed again.
- Spitting inserts at the bottom and pushes the column upward.
- Full columns block spitting.
- 3+ orthogonally connected same-color ladybugs clear.
- Matches can happen across columns.
- Cascades resolve automatically.
- FX appear when ladybugs clear.
- Move count increments only after a successful spit.
- Reset works.
- Level switching works.

## Out of Scope

Do not build:

```txt
accounts
ads
store
monetization
random endless mode
level map
power-ups
final onboarding
analytics
sound
```

## After Implementation

Report:

1. What was built.
2. Files created/changed.
3. How to run it.
4. Any asset issues.
5. Any mechanic issues discovered during implementation.
