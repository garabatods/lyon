# Chameleon Puzzle Mechanics Demo Docs

These Markdown files are for Codex to build a Flutter + Flame mechanics demo using the uploaded ZIP assets.

Recommended read order:

1. `01_ASSET_MANIFEST.md`
2. `02_MECHANICS_SPEC.md`
3. `03_FLUTTER_FLAME_IMPLEMENTATION_SPEC.md`
4. `04_LEVELS_AND_TESTING.md`
5. `05_CODEX_BUILD_PROMPT.md`

Use `05_CODEX_BUILD_PROMPT.md` as the main prompt. The other files provide supporting context.
